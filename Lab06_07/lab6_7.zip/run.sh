./add_shm $1 $2 &
./sub_shm $1 $3
./print_shm $1
